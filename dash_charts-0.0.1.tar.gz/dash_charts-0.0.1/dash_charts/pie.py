# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class pie(Component):
    """A pie component.
ExampleComponent is an example component.
It takes a property, `label`, and
displays it.
It renders an input with the property `value`
which is editable by the user.

Keyword arguments:

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- backgroundColor (string; optional):
    background color for the chart.

- data (list; required):
    list of lists,First inner list should be a list of two strings and
    each of the other inner lists should be a [string, value] pair.
    For example:  data=[['Task', 'Hours per
    Day'],['work',11],['TV',2]].

- height (string; required):
    string, height of the chart in pixels.

- is3D (boolean; required):
    boolean, select True for 3D charts.

- legendTextColor (string; optional):
    legend's color.

- pieHole (number; required):
    a number in [0-1] range showing the portion of the donut pie
    occupied by the hole.

- title (string; optional):
    title of the chart (string).

- width (string; required):
    string, width of the chart in pixels."""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, width=Component.REQUIRED, height=Component.REQUIRED, data=Component.REQUIRED, title=Component.UNDEFINED, is3D=Component.REQUIRED, pieHole=Component.REQUIRED, backgroundColor=Component.UNDEFINED, legendTextColor=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'backgroundColor', 'data', 'height', 'is3D', 'legendTextColor', 'pieHole', 'title', 'width']
        self._type = 'pie'
        self._namespace = 'dash_charts'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'backgroundColor', 'data', 'height', 'is3D', 'legendTextColor', 'pieHole', 'title', 'width']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in ['width', 'height', 'data', 'is3D', 'pieHole']:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(pie, self).__init__(**args)
